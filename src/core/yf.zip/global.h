#ifndef GLOBAL
#define GLOBAL
#define OPT  1 
#define MDEBUG 0
#define FDEBUG 0
#endif // !GLOBAL

