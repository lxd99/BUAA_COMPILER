#include<stdio.h>
const int ca = 0;
const int cb = 5;
const int cc = -5;
const char cd = 'e';
int a =5;
int b = -55;
int c = 0;
char d;
int x,y;
int main()
{
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);
	int ma = 55;
	int mb = -6;
	char mc;
	scanf("%d",&x);
	printf("%d\n",x+ mb - ca*a);
	x = x+mb - ca*a;
	scanf(" %c",&mc);
	scanf(" %c",&d);
	printf("mc is%c\n",mc);
	printf("d is%c\n",d);
	printf("%d\n",(mc));
	printf("%d\n",(d));
	printf("%d\n",mc+d);

}
